from django.apps import AppConfig


class ChatbotAppConfig(AppConfig):
    name = 'chatbot_app'
